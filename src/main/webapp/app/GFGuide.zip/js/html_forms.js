var login_main= '<form id="loginForm" class="form col-md-12 center-block" method="POST">'+
'<div class="form-group">'+
'<input type="text" name="username" id="username" class="form-control input-lg" placeholder="שם משתמש">'+
'</div>'+
'<div class="form-group">'+
'<input type="password"  name="password" id="password"  class="form-control input-lg" placeholder="סיסמא">'+
'<label id="login_error"  class="login_error"></label>'+
'</div>'+
'<div class="form-group">'+
'<button class="btn btn-primary btn-lg btn-block">כניסה</button>'+
'<span style="padding-top:10px" class="pull-left"><a href="http://gfguide.info/jsp/newUser.jsp" target="_blank">הרשמה</a></span><span style="padding-top:10px" class="pull-right"><a href="http://gfguide.info/jsp/lostIdentity.jsp" target="_blank">שכחתי סיסמא</a></span>'+
'</div>'+
'</form>';

var indexFormPart1 = '<div id="nav-indicator-fixed"></div>';
var indexFormPart2 = '</ul>';
var itemIndexLetter = '<li><a name="#X#N"></li>';
var itemInIndexForm1 = '<li><a name="#X#N"></a><div class="nav-indicator" id="nav-U#U#">#X#X</div><ul >';
var singleIndexItem = '<li><a href="javascript:#$RR$#(\'V#V#I\');" style="padding-right:5px; S#S#S" title="V#V#V"><strong style="font-family: sans-serif;" %H&&H%>V#V#V</strong></a></li>';
var itemInIndexForm2 = '</ul></li>';